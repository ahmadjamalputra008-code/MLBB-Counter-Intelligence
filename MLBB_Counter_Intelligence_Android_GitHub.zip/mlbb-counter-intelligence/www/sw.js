const VERSION = "counter-intel-pwa-v5";
const SHELL_CACHE = VERSION + "-shell";
const API_CACHE = VERSION + "-api";
const MEDIA_CACHE = VERSION + "-media";
const BASE_PATH = new URL(".", self.registration.scope).pathname;
const SHELL = [BASE_PATH, BASE_PATH + "index.html", BASE_PATH + "extras.js", BASE_PATH + "manifest.webmanifest", BASE_PATH + "icon.svg", BASE_PATH + "icon-192.png", BASE_PATH + "icon-512.png"];
const MAX_API_BYTES = 6 * 1024 * 1024;
const MAX_MEDIA_BYTES = 15 * 1024 * 1024;
const MAX_MEDIA_ENTRIES = 180;

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    await cache.addAll(SHELL);
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith("counter-intel-pwa-") && !key.startsWith(VERSION)).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

async function trimCache(cache, maxBytes, maxEntries, incomingBytes) {
  const requests = await cache.keys();
  const records = [];
  let total = 0;
  for (const request of requests) {
    const response = await cache.match(request);
    const size = Number(response && response.headers.get("content-length")) || 0;
    records.push({ request, size });
    total += size;
  }
  while (records.length >= maxEntries || total + incomingBytes > maxBytes) {
    const oldest = records.shift();
    if (!oldest) break;
    await cache.delete(oldest.request);
    total -= oldest.size;
  }
}

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.startsWith(BASE_PATH + "api/")) {
    event.respondWith((async () => {
      const cache = await caches.open(API_CACHE);
      try {
        const response = await fetch(request);
        if (response.ok) {
          const size = Number(response.headers.get("content-length")) || 0;
          if (size <= MAX_API_BYTES) {
            await trimCache(cache, MAX_API_BYTES, 500, size);
            await cache.put(request, response.clone());
          }
        }
        return response;
      } catch (_error) {
        const cached = await cache.match(request);
        if (cached) {
          const headers = new Headers(cached.headers);
          headers.set("X-Offline-Cache", "HIT");
          return new Response(cached.body, { status: cached.status, statusText: cached.statusText, headers });
        }
        return new Response(JSON.stringify({ error: "Offline: data API ini belum pernah disimpan di perangkat." }), {
          status: 503,
          headers: { "Content-Type": "application/json; charset=utf-8" }
        });
      }
    })());
    return;
  }

  if (url.pathname === BASE_PATH + "media") {
    event.respondWith((async () => {
      const cache = await caches.open(MEDIA_CACHE);
      const cached = await cache.match(request);
      if (cached) return cached;
      try {
        const response = await fetch(request);
        if (response.ok) {
          const size = Number(response.headers.get("content-length")) || 0;
          if (size > 0 && size <= 1024 * 1024) {
            await trimCache(cache, MAX_MEDIA_BYTES, MAX_MEDIA_ENTRIES, size);
            await cache.put(request, response.clone());
          }
        }
        return response;
      } catch (_error) {
        return new Response("", { status: 504, statusText: "Image unavailable offline" });
      }
    })());
    return;
  }

  if (SHELL.includes(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(SHELL_CACHE);
      const cached = await cache.match(request);
      if (cached) return cached;
      try { return await fetch(request); }
      catch (_error) { return (await cache.match(BASE_PATH + "index.html")) || new Response("Offline", { status: 503 }); }
    })());
  }
});

self.addEventListener("message", event => {
  if (event.data && event.data.type === "CACHE_APP_SHELL") {
    event.waitUntil(caches.open(SHELL_CACHE).then(cache => cache.addAll(SHELL)));
  }
});
