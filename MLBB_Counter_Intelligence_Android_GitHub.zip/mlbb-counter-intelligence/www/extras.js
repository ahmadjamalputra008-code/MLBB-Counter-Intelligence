(function () {
  "use strict";
  const API_HOSTS = ["https://arena.fastapicloud.dev/api"];
  const EXTRA_DB = "mlbb-hero-counter-offline-v3";
  const EXTRA_STORE = "api";
  const catalogs = { items: [], spells: [], emblems: [] };
  let currentCatalog = "items";
  let currentBuildRecords = [];

  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
  const arr = (v) => Array.isArray(v) ? v : (v == null ? [] : [v]);
  const first = (...values) => values.find((v) => v !== undefined && v !== null && v !== "");
  const pct = (v) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return "-";
    return (n <= 1 ? n * 100 : n).toFixed(2) + "%";
  };
  const records = (payload) => {
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload?.data?.records)) return payload.data.records;
    if (Array.isArray(payload?.records)) return payload.records;
    if (Array.isArray(payload?.data)) return payload.data;
    return [];
  };
  const dataOf = (record) => record?.data || record || {};
  const textOf = (v) => typeof v === "string" || typeof v === "number" ? String(v) : "";

  function openDb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error("IndexedDB tidak tersedia"));
      const request = indexedDB.open(EXTRA_DB, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(EXTRA_STORE)) request.result.createObjectStore(EXTRA_STORE, { keyPath: "key" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function cacheRead(key) {
    try {
      const db = await openDb();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(EXTRA_STORE, "readonly");
        const req = tx.objectStore(EXTRA_STORE).get(key);
        req.onsuccess = () => resolve(req.result?.value ?? null);
        req.onerror = () => reject(req.error);
      });
    } catch (_) { return null; }
  }
  async function cacheWrite(key, value) {
    try {
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(EXTRA_STORE, "readwrite");
        tx.objectStore(EXTRA_STORE).put({ key, data: value, savedAt: Date.now(), bytes: new Blob([JSON.stringify(value)]).size });
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
      });
    } catch (_) { /* Cache is optional; online feature remains usable. */ }
  }
  async function api(path) {
    let lastError = null;
    for (const host of API_HOSTS) {
      try {
        const response = await fetch(host + path, {
          method: "GET",
          headers: { Accept: "application/json" },
          cache: "no-store"
        });
        if (!response.ok) throw new Error("HTTP " + response.status);
        const payload = await response.json();
        if (payload && typeof payload.code === "number" && payload.code !== 0) {
          throw new Error(payload.message || payload.msg || "API mengembalikan kode " + payload.code);
        }
        await cacheWrite(path, payload);
        return { payload, cached: false, host };
      } catch (error) { lastError = error; }
    }
    const cached = await cacheRead(path);
    if (cached !== null) return { payload: cached, cached: true, host: "cache perangkat" };
    throw lastError || new Error("API tidak tersedia dan cache belum ada.");
  }
  function heroIdentifier(name) {
    const option = Array.from($("heroOptions")?.options || []).find((item) => item.value.toLowerCase() === name.toLowerCase());
    return option?.dataset?.id || name;
  }
  function unwrapBuildBuilds(payload) {
    const out = [];
    for (const record of records(payload)) {
      const d = dataOf(record);
      for (const build of arr(d.build)) out.push({ record: d, build });
    }
    return out;
  }
  function nestedSpell(value) {
    return value?.data?.__data || value?.data || value?.__data || value || {};
  }
  function guideContent(record) {
    const d = dataOf(record);
    return d.data?.data || d.data || d;
  }
  function extractGuides(payload) {
    return records(payload).map((record) => ({ record: dataOf(record), content: guideContent(record) })).filter((entry) => {
      const c = entry.content || {};
      return Boolean(c.title || c.equips || c.emblems || c.spell || c.counters || c.cooperates || c.recommend);
    });
  }
  function displayNames(value, kind) {
    return arr(value).map((item) => {
      if (typeof item === "string" || typeof item === "number") {
        if (kind === "items") {
          const found = catalogs.items.find((entry) => String(entry.id) === String(item));
          return found ? found.name : "Item #" + item;
        }
        const option = Array.from($("heroOptions")?.options || []).find((entry) => String(entry.dataset.id) === String(item));
        return option ? option.value : String(item);
      }
      if (!item || typeof item !== "object") return "";
      const deep = item.data?.__data || item.data || item;
      const identifier = first(deep.equipid, deep.heroid, deep.hero_id, deep.id, item.equipid, item.heroid, item.id);
      if (kind === "items" && identifier != null) {
        const found = catalogs.items.find((entry) => String(entry.id) === String(identifier));
        if (found) return found.name;
      }
      const heroOption = Array.from($("heroOptions")?.options || []).find((entry) => String(entry.dataset.id) === String(identifier));
      return textOf(first(deep.equipname, deep.emblemname, deep.skillname, deep.name, deep.title, item.name, item.title, heroOption?.value, identifier));
    }).filter(Boolean);
  }
  function renderGuides(guides, cached) {
    const target = $("buildResults");
    if (!guides.length) return false;
    target.innerHTML = guides.map((entry, index) => {
      const c = entry.content || {};
      const equips = displayNames(c.equips, "items");
      const emblems = displayNames(c.emblems, "emblems");
      const spells = displayNames(c.spell, "spells");
      const counters = displayNames(c.counters, "counters");
      const teammates = displayNames(c.cooperates, "teammates");
      const title = textOf(first(c.title, entry.record.title, "Panduan komunitas " + (index + 1)));
      const overview = textOf(first(c.hero?.hero_overview, c.hero_overview, c.recommend, "Panduan ini disediakan oleh konten komunitas API."));
      const version = textOf(first(c.game_version, "Versi panduan tidak dicantumkan"));
      return '<article class="build-card"><h3>' + esc(title) + '</h3>' +
        '<div class="build-meta">' + esc(version) + (cached ? ' · Cache perangkat' : ' · Rekomendasi API') + '</div>' +
        '<p class="build-meta" style="margin-top:8px">' + esc(overview) + '</p>' +
        '<div class="build-items">' + (equips.length ? equips.map((n) => '<span class="build-item">' + esc(n) + '</span>').join("") : '<span class="build-item">Equipment belum dicantumkan</span>') + '</div>' +
        '<div class="build-meta"><strong>Emblem:</strong> ' + esc(emblems.join(", ") || "Tidak dicantumkan") + '<br><strong>Battle Spell:</strong> ' + esc(spells.join(", ") || "Tidak dicantumkan") + '<br><strong>Counter:</strong> ' + esc(counters.join(", ") || "Tidak dicantumkan") + '<br><strong>Sinergi:</strong> ' + esc(teammates.join(", ") || "Tidak dicantumkan") + '</div>' +
        '</article>';
    }).join("");
    return true;
  }
  function renderBuilds(items, cached) {
    const target = $("buildResults");
    if (!items.length) {
      target.innerHTML = '<div class="empty">Tidak ada build yang dikembalikan API untuk filter ini. Coba rank atau lane lain.</div>';
      return;
    }
    target.innerHTML = items.map((entry, index) => {
      const b = entry.build;
      const emblem = b.emblem?.data || b.emblem || {};
      const spell = nestedSpell(b.battleskill);
      const spellName = first(spell.skillname, b.battleskill?.skillname, "Battle spell belum tersedia");
      const emblemName = first(emblem.emblemname, emblem.emblemattr?.emblemname, "Emblem belum tersedia");
      const emblemAttr = first(emblem.emblemattr?.emblemattr, emblem.emblemattr, "");
      const equipIds = arr(b.equipid);
      const itemNames = equipIds.map((id) => {
        const found = catalogs.items.find((x) => String(x.id) === String(id));
        return found ? found.name : "Item #" + id;
      });
      const win = pct(b.build_win_rate);
      const pick = pct(b.build_pick_rate);
      return '<article class="build-card"><h3>Rekomendasi build ' + (index + 1) + '</h3>' +
        '<div class="build-meta">Lane ID: ' + esc(entry.record.real_road ?? "-") + ' · Win rate: ' + esc(win) + ' · Pick rate: ' + esc(pick) + (cached ? ' · Data cache' : ' · Data API') + '</div>' +
        '<div class="build-items">' + (itemNames.length ? itemNames.map((n) => '<span class="build-item">' + esc(n) + '</span>').join("") : '<span class="build-item">Item belum tersedia</span>') + '</div>' +
        '<div class="build-meta"><strong>Emblem:</strong> ' + esc(emblemName) + (emblemAttr ? ' · ' + esc(emblemAttr) : '') + '<br><strong>Battle Spell:</strong> ' + esc(spellName) + '</div>' +
        (spell.skilldesc ? '<p class="build-meta" style="margin-top:8px">' + esc(spell.skilldesc) + '</p>' : '') +
        '</article>';
    }).join("");
  }
  async function loadBuild() {
    const input = $("buildHero");
    const name = (input.value || "").trim();
    if (!name) { $("buildStatus").textContent = "Masukkan nama hero terlebih dahulu."; return; }
    const rank = $("buildRank").value;
    const lane = $("buildLane").value;
    const params = new URLSearchParams({ rank, size: "20", index: "1", lang: "id" });
    if (lane) params.set("lane", lane);
    const path = "/academy/heroes/" + encodeURIComponent(heroIdentifier(name)) + "/builds?" + params.toString();
    $("buildStatus").textContent = "Mengambil build " + name + " dari API...";
    $("buildResults").innerHTML = '<div class="loading">Memuat build dan item...</div>';
    try {
      const recommendedPath = "/academy/heroes/" + encodeURIComponent(heroIdentifier(name)) + "/recommended?size=20&index=1&lang=id";
      let recommended = null;
      try { recommended = await api(recommendedPath); } catch (_) { recommended = null; }
      const [itemResponse] = await Promise.all([
        catalogs.items.length ? Promise.resolve(null) : api("/academy/equipment/expanded?size=100&index=1&lang=id").catch(() => null)
      ]);
      if (itemResponse) catalogs.items = normalizeCatalog("items", itemResponse.payload);
      const guides = recommended ? extractGuides(recommended.payload) : [];
      if (guides.length) {
        currentBuildRecords = [];
        renderGuides(guides, recommended.cached);
        $("buildStatus").textContent = guides.length + " panduan komunitas · " + recommended.host + (recommended.cached ? " · mode cache" : " · diperbarui online");
        return;
      }
      const buildPath = "/academy/heroes/" + encodeURIComponent(heroIdentifier(name)) + "/builds?" + params.toString();
      const buildResponse = await api(buildPath);
      currentBuildRecords = unwrapBuildBuilds(buildResponse.payload);
      renderBuilds(currentBuildRecords, buildResponse.cached);
      $("buildStatus").textContent = currentBuildRecords.length + " build statistik ditemukan · sumber " + buildResponse.host + (buildResponse.cached ? " · mode cache" : " · data agregat");
    } catch (error) {
      $("buildStatus").textContent = "Build belum dapat dimuat: " + error.message;
      $("buildResults").innerHTML = '<div class="empty">Tidak ada respons API atau data build belum tersimpan di perangkat.</div>';
    }
  }
  function normalizeCatalog(kind, payload) {
    return records(payload).map((record) => {
      const d = dataOf(record);
      if (kind === "items") return {
        id: first(d.equipid, d.id), name: textOf(first(d.equipname, d.name, d.title, "Equipment")),
        icon: textOf(first(d.equipicon, d.icon)), desc: textOf(first(d.equipskilldesc, d.equiptips, d.equipskill1, ""))
      };
      if (kind === "spells") {
        const deep = d.__data || d;
        return { id: first(d.battleskillid, deep.skillid), name: textOf(first(deep.skillname, d.skillname, "Battle Spell")), icon: textOf(first(deep.skillicon, d.skillicon)), desc: textOf(first(deep.skilldesc, d.skillshortdesc, "")) };
      }
      const skill = d.emblemskill || d;
      return { id: first(d.giftid, skill.skillid), name: textOf(first(skill.skillname, d.emblemname, "Emblem")), icon: textOf(first(skill.skillicon, d.attriicon)), desc: textOf(first(skill.skilldesc, skill.skilldescemblem, d.emblemattr, "")) };
    }).filter((x) => x.name);
  }
  async function loadCatalog(kind) {
    currentCatalog = kind;
    document.querySelectorAll("[data-catalog]").forEach((button) => button.classList.toggle("active", button.dataset.catalog === kind));
    const pathMap = {
      items: "/academy/equipment/expanded?size=100&index=1&lang=id",
      spells: "/academy/spells?size=100&index=1&lang=id",
      emblems: "/academy/emblems?size=100&index=1&lang=id"
    };
    $("catalogStatus").textContent = "Mengambil katalog " + kind + "...";
    $("catalogResults").innerHTML = '<div class="loading">Memuat katalog...</div>';
    try {
      const result = await api(pathMap[kind]);
      catalogs[kind] = normalizeCatalog(kind, result.payload);
      renderCatalog();
      $("catalogStatus").textContent = catalogs[kind].length + " entri · " + result.host + (result.cached ? " · cache" : " · live API");
    } catch (error) {
      $("catalogStatus").textContent = "Katalog gagal dimuat: " + error.message;
      $("catalogResults").innerHTML = '<div class="empty">Katalog ini belum tersedia secara online dan belum tersimpan offline.</div>';
    }
  }
  function renderCatalog() {
    const q = ($("catalogSearch").value || "").toLowerCase().trim();
    const items = catalogs[currentCatalog].filter((x) => (x.name + " " + x.desc).toLowerCase().includes(q));
    $("catalogResults").innerHTML = items.length ? items.map((item) =>
      '<article class="catalog-card">' + (item.icon ? '<img src="' + esc(item.icon) + '" alt="" loading="lazy" onerror="this.style.display=\'none\'">' : '') +
      '<div><h3>' + esc(item.name) + '</h3><p>' + esc(item.desc || "Deskripsi belum tersedia pada sumber data.") + '</p></div></article>'
    ).join("") : '<div class="empty">Tidak ada hasil pencarian.</div>';
  }
  function deepHeroName(node) {
    const candidates = [
      node?.main_hero?.data?.hero?.data?.name,
      node?.main_hero?.data?.name,
      node?.hero?.data?.name,
      node?.hero_name,
      node?.name
    ];
    return textOf(first(...candidates, "Hero tidak diketahui"));
  }
  async function loadMeta() {
    const rank = $("metaRank").value;
    const days = $("metaDays").value;
    const sort = $("metaSort").value;
    const path = "/heroes/rank?" + new URLSearchParams({ days, rank, sort_field: sort, size: "20", index: "1", lang: "id" }).toString();
    $("metaStatus").textContent = "Mengambil meta rank " + rank + " untuk " + days + " hari...";
    $("metaResults").innerHTML = '<div class="loading">Memuat ranking hero...</div>';
    try {
      const [rankResponse, versionResponse] = await Promise.all([
        api(path),
        api("/academy/meta/version?size=3&index=1&order=desc&lang=id").catch(() => null)
      ]);
      const rows = records(rankResponse.payload).map((record) => dataOf(record)).map((d) => ({
        name: deepHeroName(d),
        win: first(d.main_hero_win_rate, d.win_rate),
        pick: first(d.main_hero_pick_rate, d.main_hero_appearance_rate, d.pick_rate),
        ban: first(d.main_hero_ban_rate, d.ban_rate)
      }));
      $("metaResults").innerHTML = rows.length ? rows.map((row, i) => {
        const value = sort === "win_rate" ? row.win : (sort === "ban_rate" ? row.ban : row.pick);
        return '<article class="meta-card"><div class="meta-rank">' + (i + 1) + '</div><div><div class="meta-name">' + esc(row.name) + '</div><div class="meta-sub">Win ' + esc(pct(row.win)) + ' · Pick ' + esc(pct(row.pick)) + ' · Ban ' + esc(pct(row.ban)) + '</div></div><div class="meta-value">' + esc(pct(value)) + '</div></article>';
      }).join("") : '<div class="empty">API tidak mengembalikan data ranking untuk filter ini.</div>';
      let patch = "versi patch tidak tersedia";
      if (versionResponse) {
        const v = records(versionResponse.payload).map(dataOf).map((d) => first(d.game_version, d.version)).find(Boolean);
        if (v) patch = "patch " + v;
      }
      $("metaStatus").textContent = rows.length + " hero · " + patch + " · " + rankResponse.host + (rankResponse.cached ? " · cache" : " · live API");
    } catch (error) {
      $("metaStatus").textContent = "Meta tidak tersedia: " + error.message;
      $("metaResults").innerHTML = '<div class="empty">Data ranking belum dapat diambil. Coba lagi ketika koneksi pulih.</div>';
    }
  }
  function favorites() {
    try { return JSON.parse(localStorage.getItem("mlbb-counter-favorites") || "[]"); }
    catch (_) { return []; }
  }
  function saveFavorites(list) {
    localStorage.setItem("mlbb-counter-favorites", JSON.stringify(Array.from(new Set(list))));
    renderFavorites();
    updateFavoriteButton();
  }
  function currentModalName() { return ($("modalName")?.textContent || "").trim(); }
  function updateFavoriteButton() {
    const button = $("favToggle");
    if (!button) return;
    const name = currentModalName();
    const saved = favorites().includes(name);
    button.classList.toggle("saved", saved);
    button.textContent = saved ? "★" : "☆";
    button.title = saved ? "Hapus dari favorit" : "Simpan favorit";
  }
  function renderFavorites() {
    const list = favorites();
    const target = $("favoriteGrid");
    if (!target) return;
    target.innerHTML = list.length ? list.map((name) =>
      '<article class="favorite-card"><strong>' + esc(name) + '</strong><button data-unfavorite="' + esc(name) + '">HAPUS</button></article>'
    ).join("") : '<div class="empty">Belum ada hero favorit. Buka profil hero lalu tekan tombol bintang.</div>';
    target.querySelectorAll("[data-unfavorite]").forEach((button) => button.addEventListener("click", () => saveFavorites(favorites().filter((x) => x !== button.dataset.unfavorite))));
  }
  function toggleFavorite() {
    const name = currentModalName();
    if (!name || name === "Hero") return;
    const list = favorites();
    saveFavorites(list.includes(name) ? list.filter((x) => x !== name) : [...list, name]);
  }

  document.querySelectorAll("[data-catalog]").forEach((button) => button.addEventListener("click", () => loadCatalog(button.dataset.catalog)));
  $("loadBuild")?.addEventListener("click", loadBuild);
  $("buildHero")?.addEventListener("keydown", (event) => { if (event.key === "Enter") loadBuild(); });
  $("catalogSearch")?.addEventListener("input", renderCatalog);
  $("loadMeta")?.addEventListener("click", loadMeta);
  $("favToggle")?.addEventListener("click", toggleFavorite);
  $("favToggle")?.addEventListener("keydown", (event) => { if (event.key === "Enter") toggleFavorite(); });
  document.querySelectorAll(".nav button").forEach((button) => button.addEventListener("click", () => {
    if (button.dataset.view === "build" && !catalogs.items.length) loadCatalog("items");
    if (button.dataset.view === "meta") loadMeta();
    if (button.dataset.view === "favorites") renderFavorites();
  }));
  const modalName = $("modalName");
  if (modalName && window.MutationObserver) {
    new MutationObserver(updateFavoriteButton).observe(modalName, { childList: true, characterData: true, subtree: true });
  }
  renderFavorites();
})();
