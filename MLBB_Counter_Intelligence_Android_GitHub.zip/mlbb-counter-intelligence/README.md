# Counter Intel for MLBB · Android + Web

Aplikasi Android berbasis Capacitor untuk ensiklopedia hero, analisis natural counter, build, statistik meta, dan draft assistant. Data permainan diambil secara online dari Rone Arena API dan respons yang pernah berhasil dimuat disimpan di perangkat untuk akses offline.

> Proyek ini tidak berafiliasi dengan Moonton. Mobile Legends: Bang Bang dan seluruh mereknya adalah milik pemegang hak masing-masing. Rone Arena merupakan API komunitas independen.

## Fitur

- Database hero, role, specialty, lane, deskripsi, dan skill.
- Counter Lab dengan pemisahan statistik API, relasi API, dan penjelasan mekanik editorial.
- Filter counter berdasarkan rank dan periode data.
- Draft Builder untuk komposisi lawan dan tim sendiri.
- Build Lab untuk rekomendasi equipment, emblem, dan battle spell.
- Katalog equipment, spell, dan emblem beserta deskripsinya.
- Meta Board untuk win rate, pick rate, dan ban rate.
- Favorit hero yang disimpan di perangkat.
- Cache IndexedDB hingga target 40 MB untuk respons API.
- Tombol sinkronisasi offline untuk roster, detail, counter, build, item, spell, emblem, dan versi patch.
- Native HTTP melalui CapacitorHttp untuk menghindari hambatan CORS di Android WebView.
- API host utama dengan fallback otomatis ke cache lokal saat upstream tidak tersedia.
- Build APK debug otomatis melalui GitHub Actions.

## API dan akurasi

API hosts dengan failover otomatis:
- `https://arena-hv.fastapicloud.dev/api` (high-volume host)
- `https://arena.rone.dev/api` (host standar/canonical)
- `https://arena.fastapicloud.dev/api` (mirror/fallback)

Jika satu host mengembalikan rate-limit atau error upstream, aplikasi mencoba host berikutnya. Respons error seperti `UPSTREAM_RATE_LIMITED` tidak diperlakukan sebagai data sukses. Jika semua host gagal, aplikasi memakai respons yang sebelumnya tersimpan di perangkat.

Dokumentasi: https://arena.rone.dev/ dan https://arena.rone.dev/web/heroes

Endpoint yang digunakan meliputi:

- `GET /heroes`
- `GET /heroes/positions`
- `GET /heroes/{hero_identifier}`
- `GET /heroes/{hero_identifier}/relations`
- `GET /heroes/{hero_identifier}/counters`
- `GET /heroes/{hero_identifier}/stats`
- `GET /heroes/rank`
- `GET /academy/meta/version`
- `GET /academy/heroes/{hero_identifier}/recommended`
- `GET /academy/heroes/{hero_identifier}/builds` (fallback statistik/legacy)
- `GET /academy/heroes/{hero_identifier}/teammates`
- `GET /academy/equipment/expanded`
- `GET /academy/spells`
- `GET /academy/emblems`

**Penting tentang natural counter:** statistik API adalah data performa agregat berdasarkan rank dan periode, bukan bukti kausal bahwa suatu hero pasti mengalahkan hero lain. Relasi API adalah sinyal relasi dari penyedia data. Catatan mekanik editorial hanya ditampilkan untuk matchup yang memiliki alasan skill yang dapat dijelaskan. Aplikasi tidak mengubah statistik menjadi klaim hard counter. Data build dapat bersifat historis atau komunitas; periksa versi patch dan kecocokan lane sebelum digunakan.

## Build APK online melalui GitHub Actions

1. Buat repository GitHub baru, misalnya `counter-intel-mlbb`.
2. Unggah seluruh isi folder proyek ini ke root repository. Pastikan folder `.github/workflows` ikut terunggah.
3. Buka tab **Actions** di repository dan izinkan workflow berjalan jika GitHub meminta persetujuan.
4. Jalankan workflow **Build Android APK** melalui tombol **Run workflow**, atau lakukan push ke branch `main`.
5. Setelah status workflow hijau, buka hasil run dan unduh artifact **Counter-Intel-Android-APK**.
6. Ekstrak artifact, lalu instal `Counter-Intel-Android-debug.apk` di perangkat Android. Jika diminta, izinkan instalasi dari sumber tersebut.

Setiap push ke `main` atau `master` membangun APK baru dan menjalankan workflow web companion. Untuk situs web, buka **Settings → Pages** dan pilih **GitHub Actions** sebagai source bila diminta. Setiap push ke branch utama akan menerbitkan web companion. Jika membuat tag versi seperti `v2.0.0` lalu push tag tersebut, workflow juga menerbitkan GitHub Release yang berisi APK.

### Tentang jenis APK

Workflow menghasilkan **debug APK** yang ditandatangani debug key otomatis dan dapat dipasang untuk pengujian/sideload. APK ini belum merupakan rilis Play Store. Untuk distribusi publik atau Play Store, buat signing keystore milik sendiri dan tambahkan konfigurasi release signing melalui GitHub Secrets. Jangan pernah memasukkan keystore atau password ke repository.

## Build lokal (opsional)

Persyaratan: Node.js 22+, Java 21, Android SDK API 36, Android Build Tools 36.0.0.

```bash
npm install
npm run check
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK lokal akan berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Mode online dan offline

- Online: aplikasi mengambil data langsung dari API utama. Jika gagal, aplikasi mencoba host cadangan.
- Offline: aplikasi membaca respons API yang pernah tersimpan. Data yang belum pernah disinkronkan tidak dapat muncul secara offline.
- Sinkronisasi offline dapat menghasilkan banyak permintaan. Jalankan melalui koneksi stabil dan hindari menekan tombol berkali-kali.
- Data statistik lama tetap diberi status cache; aplikasi tidak menyamarkannya sebagai data live.
- Portrait hero dimuat dari host gambar eksternal. Tidak semua gambar dijamin tersedia offline.

## Batas ukuran 50 MB

50 MB diperlakukan sebagai plafon anggaran ukuran, bukan target yang harus dipenuhi dengan file kosong. APK akan lebih ringan karena roster, build, statistik, dan gambar diperbarui dari API. Cache offline dikelola terpisah di penyimpanan aplikasi dan tidak seluruhnya ditanam ke APK.

## Struktur proyek

```text
counter-intel-mlbb/
  .github/workflows/android-apk.yml
  assets/icon.png
  assets/splash.png
  docs/API_DATA_MAP.md
  docs/COUNTER_METHODOLOGY.md
  scripts/check.mjs
  www/index.html
  www/extras.js
  www/sw.js
  www/manifest.webmanifest
  www/icon.svg
  capacitor.config.json
  package.json
  README.md
  QA_REPORT.md
```
