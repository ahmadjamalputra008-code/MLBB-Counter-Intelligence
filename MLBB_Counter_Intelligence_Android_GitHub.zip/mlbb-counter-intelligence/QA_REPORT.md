# QA Report · Counter Intel v2.0

## Pemeriksaan yang berhasil dijalankan pada paket sumber

| Pemeriksaan | Hasil |
|---|---|
| Sintaks inline JavaScript | PASS |
| Sintaks modul tambahan `extras.js` | PASS |
| Sintaks service worker | PASS |
| ID HTML duplikat | Tidak ditemukan |
| Referensi ID statis dari skrip | Semua ditemukan |
| Konfigurasi Capacitor `webDir` | PASS |
| CapacitorHttp native fetch patch | Aktif pada konfigurasi |
| Workflow membuat platform Android | PASS pada inspeksi konfigurasi |
| Workflow membangun APK debug | Task `assembleDebug` terkonfigurasi |
| Workflow mengunggah APK artifact | PASS pada inspeksi konfigurasi |
| Workflow deployment web companion | Tersedia |
| YAML workflow Android dan Pages | Valid secara sintaks |
| Manifest dan ikon | Tersedia |
| API host utama dan fallback cache | Terkonfigurasi |
| Referensi hostname API lama | Tidak ditemukan |
| App shell | Sekitar 91 KB, jauh di bawah plafon 50 MB |

## Belum diverifikasi

1. Build Gradle Android belum dijalankan dalam lingkungan ini karena Android SDK/Gradle project belum tersedia di container. GitHub Actions akan menghasilkan APK setelah source diunggah ke repository dan workflow dijalankan.
2. Koneksi API publik belum dapat diuji langsung dari lingkungan build. Respons aktual, uptime, rate limit, dan CORS mengikuti layanan Rone Arena.
3. Instalasi dan uji perangkat fisik Android belum dilakukan.
4. Natural-counter editorial baru mencakup matchup yang memiliki catatan mekanik eksplisit. Matchup lain ditampilkan berdasarkan statistik/relasi API tanpa mengarang alasan mekanik.

## Kesimpulan

Paket sumber lolos pemeriksaan statis yang tercantum di atas dan sudah dilengkapi pipeline GitHub Actions. Status ini **bukan** pernyataan bahwa APK sudah berhasil dibangun atau seluruh endpoint API live telah lulus pengujian. APK final baru dapat dinyatakan lulus setelah GitHub Actions berhasil dan APK diuji pada perangkat Android.


## API failover patch

- Menambahkan high-volume host `arena-hv.fastapicloud.dev`, canonical host `arena.rone.dev`, dan mirror `arena.fastapicloud.dev` sebagai urutan failover.
- Respons JSON `status: error`, kode string non-OK (termasuk `UPSTREAM_RATE_LIMITED`), dan kode numerik nonzero kini dianggap gagal sehingga host berikutnya dicoba.
- Cache lokal tetap digunakan setelah seluruh host gagal.
- Pemeriksaan ini memvalidasi kode dan struktur failover; uji live tetap bergantung pada ketersediaan host API.
