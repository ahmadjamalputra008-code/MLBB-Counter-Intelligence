import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const fail = (message) => { console.error('FAIL:', message); process.exitCode = 1; };
const pass = (message) => console.log('PASS:', message);

const html = read('www/index.html');
const extras = read('www/extras.js');
const sw = read('www/sw.js');
const packageJson = JSON.parse(read('package.json'));
const capacitor = JSON.parse(read('capacitor.config.json'));
const manifest = JSON.parse(read('www/manifest.webmanifest'));
const workflow = read('.github/workflows/android-apk.yml');

const inlineScripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
if (!inlineScripts.length) fail('Tidak ditemukan inline application script');
else {
  try { inlineScripts.forEach((source) => new vm.Script(source)); pass('Sintaks inline JavaScript valid'); }
  catch (error) { fail('Sintaks inline JavaScript: ' + error.message); }
}
try { new vm.Script(extras); pass('Sintaks extras.js valid'); }
catch (error) { fail('Sintaks extras.js: ' + error.message); }
try { new vm.Script(sw); pass('Sintaks service worker valid'); }
catch (error) { fail('Sintaks service worker: ' + error.message); }

const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map((m) => m[1]);
const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
if (duplicateIds.length) fail('ID HTML duplikat: ' + [...new Set(duplicateIds)].join(', '));
else pass('Tidak ada ID HTML duplikat');
const idSet = new Set(ids);
const refs = new Set([...html, extras].join('\n').matchAll(/\$\(["']([A-Za-z][A-Za-z0-9_-]*)["']\)/g).map((m) => m[1]));
const missing = [...refs].filter((id) => !idSet.has(id));
if (missing.length) fail('Referensi elemen tidak ditemukan: ' + missing.join(', '));
else pass('Semua referensi elemen statis ditemukan');

if (capacitor.webDir !== 'www') fail('Capacitor webDir harus www');
else pass('Capacitor webDir benar');
if (capacitor.plugins?.CapacitorHttp?.enabled !== true) fail('CapacitorHttp native fetch patch harus aktif');
else pass('CapacitorHttp native networking aktif');
if (!packageJson.dependencies?.['@capacitor/android'] || !packageJson.dependencies?.['@capacitor/core']) fail('Dependency Capacitor Android/core tidak lengkap');
else pass('Dependency Capacitor tersedia');
if (!workflow.includes('assembleDebug') || !workflow.includes('upload-artifact@v4')) fail('Workflow belum membangun dan mengunggah APK');
else pass('GitHub Actions membangun APK dan mengunggah artifact');
if (!workflow.includes('npx cap add android') || !workflow.includes('npx cap sync android')) fail('Workflow Android platform tidak lengkap');
else pass('Workflow membuat dan sinkronisasi platform Android');
if (!manifest.icons?.length) fail('Manifest tidak memiliki ikon');
else pass('Manifest PWA memiliki ikon');
if (!sw.includes('BASE_PATH + \"extras.js\"')) fail('Service worker tidak memasukkan extras.js ke app shell');
else pass('Service worker memasukkan extras.js');
const apiHosts = ['https://arena-hv.fastapicloud.dev/api', 'https://arena.rone.dev/api', 'https://arena.fastapicloud.dev/api'];
if (apiHosts.every((host) => html.includes(host) && extras.includes(host))) pass('Tiga host API terdokumentasi tersedia untuk failover');
else fail('Daftar host API failover tidak lengkap');
if (!html.includes('data.status===\"error\"') || !extras.includes('payload.status === \"error\"')) fail('Respons error upstream belum ditangani');
else pass('Respons rate-limit dan upstream error ditangani sebagai kegagalan, bukan data hero');
if (html.includes('mlbb.rone.dev/api')) fail('Terdapat referensi API hostname lama');
else pass('Tidak ada hostname API lama');

for (const p of ['assets/icon.png', 'assets/splash.png', 'www/icon-192.png', 'www/icon-512.png']) {
  if (!fs.existsSync(path.join(root, p))) fail('Asset tidak ditemukan: ' + p);
  else pass('Asset tersedia: ' + p);
}
const totalBytes = ['www/index.html', 'www/extras.js', 'www/sw.js'].reduce((sum, p) => sum + fs.statSync(path.join(root, p)).size, 0);
if (totalBytes > 50 * 1024 * 1024) fail('App shell melebihi anggaran 50 MB');
else pass('App shell di bawah plafon 50 MB (' + Math.round(totalBytes / 1024) + ' KB)');

if (process.exitCode) process.exit(process.exitCode);
console.log('\nSemua pemeriksaan statis selesai. Ini bukan pengganti build Android dan uji API live.');
