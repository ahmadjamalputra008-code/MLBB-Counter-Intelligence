# API Data Map

API is a third-party community service. The app uses the documented primary host and falls back to cached responses when the upstream is unavailable. Endpoint availability, rate limits, response shapes, and data freshness remain under the provider's control.

| App feature | Endpoint | Interpretation |
|---|---|---|
| Hero roster | `GET /heroes` | Paginated hero records |
| Role and lane | `GET /heroes/positions` | Position metadata |
| Hero detail and skills | `GET /heroes/{hero_identifier}` | Profile payload; parser tolerates nested fields |
| Hero relations | `GET /heroes/{hero_identifier}/relations` | API relation signal, not a guaranteed matchup outcome |
| Team synergy | `GET /academy/heroes/{hero_identifier}/teammates` | Teammate synergy signal; not a guaranteed win condition |
| Counter Lab | `GET /heroes/{hero_identifier}/counters` | Counter candidates with rank and time-window filters |
| Hero stats | `GET /heroes/{hero_identifier}/stats` | Hero statistics |
| Meta Board | `GET /heroes/rank` | Rank-aggregated win, pick, and ban rates |
| Build Lab | `GET /academy/heroes/{hero_identifier}/recommended` | Community guides with equipment, emblem, spell, counters, and synergies; legacy build stats are a fallback |
| Legacy build fallback | `GET /academy/heroes/{hero_identifier}/builds` | Historical/aggregate equipment IDs, emblem, spell, pick rate, and win rate |
| Equipment catalog | `GET /academy/equipment/expanded` | Equipment names, icons, passive descriptions |
| Battle spells | `GET /academy/spells` | Spell name, icon, effect description |
| Emblems | `GET /academy/emblems` | Emblem talent name, icon, effect description |
| Patch version | `GET /academy/meta/version` | Version history data |

The app preserves raw provider values where units are not explicitly documented. It does not infer a percentage from an impact value unless the API contract defines the unit.
