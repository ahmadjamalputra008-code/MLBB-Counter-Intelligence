# Counter Methodology

## Three evidence layers

1. **Statistical counter:** candidates returned by the provider's counter endpoint under a selected rank and time window. This describes observed aggregate association, not a causal guarantee.
2. **API relation:** a relationship marker returned by the provider. It is displayed separately from statistics because the underlying definition may differ.
3. **Mechanics note:** a curated explanation of an interaction between skills, such as dash interruption, crowd-control protection, anti-heal, or HP-based true damage. Only explicitly curated pairs are shown as mechanics notes.

## Draft score

Draft Builder combines counter coverage across the selected enemy heroes, the provider's impact value when available, and role coverage in the user's current team. The score is a prioritization index, not a win probability. It should not be interpreted as a tier list.

## Matchup caveats

- Skill interactions can change with patches.
- Counter value depends on lane, draft order, player proficiency, team composition, and itemization.
- A hero may be a statistical counter at one rank and not another.
- A natural counter is not automatically a hard counter.
- If the app has no curated mechanic note for a matchup, it says so rather than inventing a reason.
